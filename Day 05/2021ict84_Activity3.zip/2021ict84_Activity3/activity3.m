numVoters = input('Enter the total number of voters: ');

votes = [0, 0, 0, 0]; % [A, B, C, D]

for i = 1:numVoters
    fprintf('\nVoter %d: Please choose a candidate (1-4):\n', i);
    fprintf('1. Candidate A\n');
    fprintf('2. Candidate B\n');
    fprintf('3. Candidate C\n');
    fprintf('4. Candidate D\n');
    
    vote = input('Enter your choice (1-4): ');
    
    switch vote
        case 1
            votes(1) = votes(1) + 1;
        case 2
            votes(2) = votes(2) + 1; 
        case 3
            votes(3) = votes(3) + 1;
        case 4
            votes(4) = votes(4) + 1;
        otherwise
            fprintf('Invalid vote! Please enter a valid option (1-4).\n');
            continue; 
    end
end


fprintf('\nVote counts:\n');
fprintf('Candidate A: %d votes\n', votes(1));
fprintf('Candidate B: %d votes\n', votes(2));
fprintf('Candidate C: %d votes\n', votes(3));
fprintf('Candidate D: %d votes\n', votes(4));


[~, winnerIndex] = max(votes);
candidates = {'A', 'B', 'C', 'D'};
fprintf('\nWinner: Candidate %s\n', candidates{winnerIndex});


while true
    fprintf('\n--- Visualization Menu ---\n');
    fprintf('1. Show Bar Chart of Votes\n');
    fprintf('2. Show Pie Chart of Votes\n');
    fprintf('3. Show Scatter Plot\n');
    fprintf('4. Exit\n');
    
    choice = input('Enter your choice (1-4): ');
    
    switch choice
        case 1
            figure;
            bar(votes);
            title('Vote Counts for Candidates');
            xlabel('Candidates');
            ylabel('Votes');
            set(gca, 'XTickLabel', {'A', 'B', 'C', 'D'});
            grid on;
        case 2
            figure;
            pie(votes);
            title('Vote Distribution for Candidates');
            legend('Candidate A', 'Candidate B', 'Candidate C', 'Candidate D');
        case 3
            figure;
            scatter(1:4, votes, 100, 'filled');
            title('Creative Scatter Plot of Votes');
            xlabel('Candidates');
            ylabel('Votes');
            set(gca, 'XTick', 1:4, 'XTickLabel', {'A', 'B', 'C', 'D'});
            grid on;
        case 4
            disp('Exiting the visualization menu...');
            break;
        otherwise
            fprintf('Invalid choice! Please choose between 1 and 4.\n');
    end
end

fprintf('\nVoting session complete.\n');
