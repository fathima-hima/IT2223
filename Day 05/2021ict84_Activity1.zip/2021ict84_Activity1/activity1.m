balance = 1000;

fprintf('Welcome to the ATM Simulator!\n');

while true
    fprintf('\n--- ATM Menu ---\n');
    fprintf('1. Deposit\n');
    fprintf('2. Withdraw\n');
    fprintf('3. Balance Inquiry\n');
    fprintf('4. Exit\n');
    
    choice = input('Please select an option (1-4): ');
    
    switch choice
        case 1 
            amount = input('Enter the amount to deposit: ');
            if amount > 0
                balance = balance + amount;
                fprintf('Deposit successful! Your new balance : $%.2f\n', balance);
            else
                fprintf('Invalid amount. Please enter a positive value.\n');
            end
            
        case 2 
            amount = input('Enter the amount to withdraw: ');
            if amount <= 0
                fprintf('Invalid amount. Please enter a positive value.\n');
            elseif amount > balance
                fprintf('Insufficient funds! Current balance: $%.2f\n', balance);
            else
                balance = balance - amount;
                fprintf('Withdrawal successful! Your New balance: $%.2f\n', balance);
            end
            
        case 3  
            fprintf('Your current balance is: $%.2f\n', balance);
            
        case 4 
            fprintf('Thank you for using the ATM. Goodbye!\n');
            break;
            
        otherwise
            fprintf('Invalid selection. Please choose an option from 1 to 4.\n');
    end
end