
marks = zeros(1, 5);

for i = 1:5
    marks(i) = input(['Enter marks for Student ', num2str(i), ' (out of 100): ']);
    
    if marks(i) >= 90
        grade = 'A';
    elseif marks(i) >= 80
        grade = 'B';
    elseif marks(i) >= 70
        grade = 'C';
    elseif marks(i) >= 60
        grade = 'D';
    else
        grade = 'F';
    end
    fprintf('Student %d received grade: %s\n', i, grade);
end

while true
    disp('Menu:');
    disp('1. Show all marks as a bar chart');
    disp('2. Show average marks');
    disp('3. Exit');
    
    choice = input('Enter your choice (1, 2, or 3): ');
    
    switch choice
        case 1
            figure;
            bar(marks);
            title('Marks of 5 Students');
            xlabel('Student');
            ylabel('Marks');
            xticks(1:5);
            xticklabels({'Student 1', 'Student 2', 'Student 3', 'Student 4', 'Student 5'});
            grid on;
            
        case 2
            avg_marks = mean(marks);
            fprintf('The average marks are: %.2f\n', avg_marks);
            
        case 3
            disp('Thank you for using the program! Goodbye.');
            break;
            
        otherwise
            disp('Invalid choice. Please choose 1, 2, or 3.');
    end
end
